package docker

type DockerRegistryTagsResponse struct {
	Name string
	Tags []string
}
