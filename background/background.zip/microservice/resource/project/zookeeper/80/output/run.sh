#!/bin/sh
sh /home/work/service/output/bin/zkServer.sh start-foreground
