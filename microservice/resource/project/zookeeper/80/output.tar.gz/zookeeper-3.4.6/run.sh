#!/bin/sh
sh ./bin/zkServer.sh start-foreground
