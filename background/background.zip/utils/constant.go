package utils

const (
	STATIC_DIR = "/src/opensource/chaos/foreground"
	PROP_FILE  = "/src/opensource/chaos/resources/core.properties"
	TMPL_NAME  = "html"

	IMAGES_TAG_STYLE_NORMAL = "TIME_COMMITID_JOBID"
	IMAGES_TAG_STYLE_SIMPLE = "TIME"
)
